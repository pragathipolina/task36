package com.DecoratorPattern;

public interface CarModel {
	public void model();

}
